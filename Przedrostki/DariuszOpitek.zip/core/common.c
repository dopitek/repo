#include <stdlib.h>
#include "common.h"

/*
model initialize_model()
{
    model model_t;
    model_t.in_filename = NULL;
    model_t.out_filename = NULL;
    model_t.prefix = NULL;
    return model_t;
}

void destroy_model(model model_t)
{
    if (model_t.in_filename != NULL)
        free(model_t.in_filename);
    if (model_t.out_filename != NULL)
        free(model_t.out_filename);
    if (model_t.prefix != NULL)
        free(model_t.prefix);
}
*/

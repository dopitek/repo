#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include "common.h"

model menu(int argc, char ** argv);
int validate_input(model model_t);

#endif

#ifndef FILEEXT_H_INCLUDED
#define FILEEXT_H_INCLUDED

char* read_line(FILE* file);
int file_exists(const char *fileName);

#endif
